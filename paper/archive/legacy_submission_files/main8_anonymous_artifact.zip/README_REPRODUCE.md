# Reproduce the ICTAI Main8 Audit

## Requirements

- Python 3.12 (Python 3.10+ should work with `requirements.txt`)
- A LaTeX distribution providing `pdflatex`, `bibtex`, and `pdfinfo`
- The bundled raw yield CSV and NASA POWER ZIP under `data/raw/`

## One Command

From PowerShell at the repository root on Windows:

```powershell
.\scripts\reproduce_main8_audit.ps1
```

On a Unix-like environment with Python and LaTeX on `PATH`:

```bash
bash scripts/reproduce_main8_audit.sh
```

The command rebuilds the weather reconstruction evidence, runs E1--E10, executes
the unit tests, regenerates the LaTeX tables and vector figures, builds the blind
paper, and writes `submission/main8_final_audit.json`.

## Outputs

- `artifacts/audit/selection/selected_config.json`: validation-only selection record.
- `artifacts/audit/final_test/row_level_predictions.csv`: all locked-test predictions.
- `artifacts/audit/bootstrap/`: deterministic year-block samples and intervals.
- `artifacts/audit/tail/`: below-trend fidelity metrics and event predictions.
- `artifacts/audit/leakage/`: full-series versus train-only target comparison.
- `paper/generated/`: generated tables, figures, and manuscript number macros.
- `paper/ictai2026_blind/main.pdf`: blind final-paper build.

The selected configuration and every final-test result are generated after the
validation-only selection step. The final test is not used to select a model,
feature family, threshold, or gate condition.
