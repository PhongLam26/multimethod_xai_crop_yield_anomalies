# Reproduce the ICTAI Main9 Audit

## Requirements

- Python 3.12 (Python 3.10+ should work with `requirements.txt`)
- A LaTeX distribution providing `pdflatex`, `bibtex`, and `pdfinfo`
- The bundled raw yield CSV and NASA POWER ZIP under `data/raw/`

## One Command

From PowerShell at the repository root on Windows:

```powershell
.\scripts\reproduce_main9_audit.ps1
```

On a Unix-like environment with Python and LaTeX on `PATH`:

```bash
bash scripts/reproduce_main9_audit.sh
```

The command rebuilds the weather reconstruction evidence, runs E1--E10, executes
the unit tests and reference audit, regenerates the LaTeX tables and figures,
builds the blind paper, and writes `submission/main9_final_audit.json`.

## Outputs

- `artifacts/audit/selection/selected_config.json`: validation-only selection record.
- `artifacts/audit/final_test/row_level_predictions.csv`: all locked-test predictions.
- `artifacts/audit/bootstrap/`: deterministic year-block samples and intervals.
- `artifacts/audit/fidelity_gate_components.csv`: each gate component and its
  observed status.
- `artifacts/audit/final_test/baseline_prediction_audit.csv`: baseline-vector
  hashes and pairwise differences.
- `artifacts/audit/references/`: 32-reference verification and citation usage.
- `artifacts/audit/tail/`: below-trend fidelity metrics and event predictions.
- `artifacts/audit/leakage/`: full-series versus train-only target comparison.
- `paper/generated/`: generated tables, figures, and manuscript number macros.
- `paper/ictai2026_blind/main.pdf`: blind final-paper build.

The selected configuration and every final-test result are generated after the
validation-only selection step. The final test is not used to select a model,
feature family, threshold, or gate condition.
