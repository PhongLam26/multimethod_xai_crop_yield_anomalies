from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from crop_yield_xai.audit_rules import final_gate_status, paired_error_pass, tail_component_pass


class GateLogicTests(unittest.TestCase):
    def setUp(self):
        self.config = {"tail_thresholds": {"z<-1": {"min_sign_accuracy": 0.5, "min_spearman": 0.0, "min_top_k_recall": 0.1}}}

    def test_paired_rule_requires_upper_interval_below_zero(self):
        self.assertTrue(paired_error_pass(-0.001))
        self.assertFalse(paired_error_pass(0.0))

    def test_tail_rule_and_final_conjunction(self):
        row = {"threshold": "z<-1", "paired_delta_rmse_ci95_high": -0.01, "paired_delta_mae_ci95_high": -0.01, "sign_accuracy": 0.5, "spearman": 0.1, "top_k_recall": 0.1}
        self.assertTrue(tail_component_pass(row, self.config))
        self.assertEqual(final_gate_status({"overall": True, "tail": True}), "PASS")
        self.assertEqual(final_gate_status({"overall": True, "tail": False}), "FAIL")
