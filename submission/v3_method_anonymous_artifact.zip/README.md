# Anonymous V3 Method Artifact

This package supports the Fidelity-Gated XAI method route. It contains the V3 source/PDF,
pre-registered V2 specifications, scripts, aggregate experiment evidence, and hash manifests.

## Included evidence

- Synthetic ground-truth benchmark and EIA external-domain result.
- County-level winter-wheat V2 selection/gate summaries and audit.
- No local raw NASS, NASA POWER, or Census responses are redistributed in this archive.

## Reconstructing V2 inputs

Set `NASS_API_KEY` in the runtime environment, then run:

```text
python scripts/download_nass_v2_county.py --crop WHEAT --year-ge 2000 --state <STATE>
python scripts/build_v2_county_yield_panel.py
python scripts/download_v2_county_centroids.py
python scripts/download_nasa_power_v2_weather.py --workers 2
python scripts/build_v2_weather_features.py
python scripts/run_v2_county_weather_experiment.py
python scripts/audit_v2_pipeline.py
```

The V2 raw payloads are intentionally excluded pending source redistribution review. The included manifests retain source and checksum evidence; no credential is packaged.
